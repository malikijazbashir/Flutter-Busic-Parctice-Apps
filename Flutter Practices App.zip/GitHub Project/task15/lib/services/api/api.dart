abstract class Api {
  Future<bool> likePost(int postId);
}
