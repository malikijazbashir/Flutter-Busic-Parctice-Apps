import 'base_model.dart';
class HomeViewModel extends BaseModel {
}