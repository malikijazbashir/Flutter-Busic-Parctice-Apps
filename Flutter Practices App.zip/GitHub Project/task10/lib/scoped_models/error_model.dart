import 'package:scoped_model/scoped_model.dart';

class ErrorModel extends Model {
}