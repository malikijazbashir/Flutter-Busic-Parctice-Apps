class ListItem {
  final String title;
  final String description;

  ListItem({this.title, this.description});
}